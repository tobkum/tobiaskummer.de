Ribband: press images

Free to use in coverage of Ribband (articles, reviews, videos, newsletters). Please do not alter the
screenshots beyond cropping and scaling, and do not use the mark for anything else than referring to Ribband.

phone/      eight screenshots, 1080 x 1920, JPEG
tablet/     eight screenshots of a 10-inch tablet, 2560 x 1440, JPEG (English set only)
brand/      the app icon (512, 1024, SVG), the stacked mark for light and for dark ground (SVG, PNG), and the
            feature graphic 1024 x 500

The screenshots show the app with sample articles written for them.
Press page: https://tobiaskummer.de/ribband/press.html
